#!/usr/bin/env bash
echo "Error message from stderr" 1>&2
echo "Error message from stdout"

return 123